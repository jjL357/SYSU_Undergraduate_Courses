Quick README

This repository contains code for simulating operations in the assembly model of brain computation.
